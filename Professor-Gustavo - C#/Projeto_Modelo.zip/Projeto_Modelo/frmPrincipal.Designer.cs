﻿
namespace Projeto_Modelo
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lógica1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lógica2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lógica3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bancoDeDadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastro1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastro2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consulta1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consulta2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.praticandoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prática1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prática2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prática3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercíciosToolStripMenuItem,
            this.bancoDeDadosToolStripMenuItem,
            this.praticandoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exercíciosToolStripMenuItem
            // 
            this.exercíciosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lógica1ToolStripMenuItem,
            this.lógica2ToolStripMenuItem,
            this.lógica3ToolStripMenuItem,
            this.toolStripSeparator1,
            this.sairToolStripMenuItem});
            this.exercíciosToolStripMenuItem.Name = "exercíciosToolStripMenuItem";
            this.exercíciosToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.exercíciosToolStripMenuItem.Text = "Exercícios";
            // 
            // lógica1ToolStripMenuItem
            // 
            this.lógica1ToolStripMenuItem.Name = "lógica1ToolStripMenuItem";
            this.lógica1ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lógica1ToolStripMenuItem.Text = "Lógica 1";
            this.lógica1ToolStripMenuItem.Click += new System.EventHandler(this.lógica1ToolStripMenuItem_Click);
            // 
            // lógica2ToolStripMenuItem
            // 
            this.lógica2ToolStripMenuItem.Name = "lógica2ToolStripMenuItem";
            this.lógica2ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lógica2ToolStripMenuItem.Text = "Lógica 2";
            // 
            // lógica3ToolStripMenuItem
            // 
            this.lógica3ToolStripMenuItem.Name = "lógica3ToolStripMenuItem";
            this.lógica3ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lógica3ToolStripMenuItem.Text = "Lógica 3";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(221, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // bancoDeDadosToolStripMenuItem
            // 
            this.bancoDeDadosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastro1ToolStripMenuItem,
            this.cadastro2ToolStripMenuItem,
            this.consulta1ToolStripMenuItem,
            this.consulta2ToolStripMenuItem});
            this.bancoDeDadosToolStripMenuItem.Name = "bancoDeDadosToolStripMenuItem";
            this.bancoDeDadosToolStripMenuItem.Size = new System.Drawing.Size(132, 24);
            this.bancoDeDadosToolStripMenuItem.Text = "Banco de Dados";
            // 
            // cadastro1ToolStripMenuItem
            // 
            this.cadastro1ToolStripMenuItem.Name = "cadastro1ToolStripMenuItem";
            this.cadastro1ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cadastro1ToolStripMenuItem.Text = "Cadastro 1";
            // 
            // cadastro2ToolStripMenuItem
            // 
            this.cadastro2ToolStripMenuItem.Name = "cadastro2ToolStripMenuItem";
            this.cadastro2ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.cadastro2ToolStripMenuItem.Text = "Cadastro 2";
            // 
            // consulta1ToolStripMenuItem
            // 
            this.consulta1ToolStripMenuItem.Name = "consulta1ToolStripMenuItem";
            this.consulta1ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.consulta1ToolStripMenuItem.Text = "Consulta 1";
            // 
            // consulta2ToolStripMenuItem
            // 
            this.consulta2ToolStripMenuItem.Name = "consulta2ToolStripMenuItem";
            this.consulta2ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.consulta2ToolStripMenuItem.Text = "Consulta 2";
            // 
            // praticandoToolStripMenuItem
            // 
            this.praticandoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prática1ToolStripMenuItem,
            this.prática2ToolStripMenuItem,
            this.prática3ToolStripMenuItem});
            this.praticandoToolStripMenuItem.Name = "praticandoToolStripMenuItem";
            this.praticandoToolStripMenuItem.Size = new System.Drawing.Size(94, 24);
            this.praticandoToolStripMenuItem.Text = "Praticando";
            // 
            // prática1ToolStripMenuItem
            // 
            this.prática1ToolStripMenuItem.Name = "prática1ToolStripMenuItem";
            this.prática1ToolStripMenuItem.Size = new System.Drawing.Size(149, 26);
            this.prática1ToolStripMenuItem.Text = "Prática 1";
            // 
            // prática2ToolStripMenuItem
            // 
            this.prática2ToolStripMenuItem.Name = "prática2ToolStripMenuItem";
            this.prática2ToolStripMenuItem.Size = new System.Drawing.Size(149, 26);
            this.prática2ToolStripMenuItem.Text = "Prática 2";
            // 
            // prática3ToolStripMenuItem
            // 
            this.prática3ToolStripMenuItem.Name = "prática3ToolStripMenuItem";
            this.prática3ToolStripMenuItem.Size = new System.Drawing.Size(149, 26);
            this.prática3ToolStripMenuItem.Text = "Prática 3";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPrincipal";
            this.Text = "Projeto Modelo da Turma 30 - Técnico em Informática";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lógica1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lógica2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lógica3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bancoDeDadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastro1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastro2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consulta1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consulta2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem praticandoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prática1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prática2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prática3ToolStripMenuItem;
    }
}